# Promoción automática de iFlows a QA

Este paquete transforma los proyectos exportados desde SAP Cloud Integration
cuando un Pull Request se integra en la rama `qa`.

## Archivos

Copiar al repositorio respetando estas rutas:

```text
.github/workflows/promote-to-qa.yml
scripts/rename_to_qa.py
```

## Flujo

1. Crear la rama `qa`.
2. Copiar estos dos archivos inicialmente a `develop` y `qa`.
3. Crear un Pull Request con base `qa` y compare `develop`.
4. Aprobar y hacer merge.
5. El workflow se ejecuta por el `push` recibido en `qa`.
6. El workflow agrega `_QA`, guarda los cambios y realiza un commit automático.

## Transformaciones

Para cada carpeta que contenga estos archivos:

```text
.project
META-INF/MANIFEST.MF
```

se realizan estas modificaciones:

```text
iflow1_copy/            -> iflow1_copy_QA/
iflow1.iflw             -> iflow1_QA.iflw
```

En `.project`:

```xml
<name>iflow1_copy</name>
```

queda:

```xml
<name>iflow1_copy_QA</name>
```

En `META-INF/MANIFEST.MF` se actualizan exclusivamente:

```text
Bundle-Name
Bundle-SymbolicName
Origin-Bundle-Name
Origin-Bundle-SymbolicName
```

El contenido BPMN del archivo `.iflw` no se modifica.

## Idempotencia

Estos valores:

```text
iflow1
iflow1_QA
iflow1_QA_QA
```

se normalizan siempre como:

```text
iflow1_QA
```

## Prueba local opcional

Desde la raíz del repositorio:

```bash
python scripts/rename_to_qa.py --root . --suffix _QA
```

Luego revisar:

```bash
git status
git diff
```

## Permiso de escritura

El workflow declara:

```yaml
permissions:
  contents: write
```

Si GitHub impide el `git push`, revisar:

```text
Settings
  -> Actions
  -> General
  -> Workflow permissions
  -> Read and write permissions
```

También puede existir una regla de protección sobre `qa` que impida que
`github-actions[bot]` escriba directamente.

## Advertencia sobre promociones posteriores

La rama `qa` tendrá carpetas y archivos renombrados. Por eso, Git puede
interpretar promociones posteriores desde `develop` como eliminaciones,
altas o renombres y eventualmente mostrar conflictos.

Antes de usarlo con todos los paquetes:

1. Probar con un único iFlow.
2. Hacer una segunda modificación en `develop`.
3. Crear un segundo Pull Request hacia `qa`.
4. Confirmar que Git reconoce correctamente el renombre.

Si aparecen conflictos recurrentes, conviene cambiar el diseño para generar
la variante QA como un artefacto de salida separado, en lugar de mantenerla
como una rama que recibe merges normales.
